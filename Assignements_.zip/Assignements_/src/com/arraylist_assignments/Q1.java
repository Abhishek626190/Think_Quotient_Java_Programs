package com.arraylist_assignments;

import java.util.ArrayList;
//import java.util.*;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<>();
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
 		System.out.println(al);
 		System.out.println(al.size());
 		
//		ArrayList l=new ArrayList();
// 		l.add(l);
// 		l.add("Abhi");
// 		l.add(10.5);
// 		l.add(10.5f);
// 		l.add(true);
// 		System.out.println(l);)

	}

}
