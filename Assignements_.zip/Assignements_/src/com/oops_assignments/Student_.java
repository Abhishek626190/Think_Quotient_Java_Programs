package com.oops_assignments;

//import com.oops.MyDate;

public class Student_ {
	String name;
	int age;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student_ obj1=new Student_();
		Student_ obj2=new Student_();
		obj1.name="Abhishek";
		obj2.age=23;
		System.out.println(obj1.name);
		System.out.println(obj2.age);
//		MyDate obj=new MyDate();
//		obj.setMm(11);
//		int r=obj.getMm();
//		System.out.println("Calling getter and setter");
//		System.out.println( r);

		
	}

}
