package com.oops_assignments;

public class Hash_Code {
	static int hashcode;
	public void check(int hc)
	{
		 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hash_Code obj=new Hash_Code();
		Hash_Code obj1=new Hash_Code();
 		System.out.println(obj);
		System.out.println(obj1);

		
		 

	}

}
