package com.hashsetassignments;

import java.util.HashSet;

public class Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer>hs=new HashSet<>();
		boolean b=hs.isEmpty();
		System.out.println(b);

	}

}
