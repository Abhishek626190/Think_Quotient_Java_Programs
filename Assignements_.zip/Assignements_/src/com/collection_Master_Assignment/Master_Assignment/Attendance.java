package com.collection_Master_Assignment.Master_Assignment;

public class Attendance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
