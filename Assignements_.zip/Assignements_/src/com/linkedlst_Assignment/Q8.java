package com.linkedlst_Assignment;

import java.util.LinkedList;

public class Q8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> l=new LinkedList<>();
		l.add(10);
		l.add(11);
		l.add(12);
		l.add(13);
		l.add(14);
		System.out.println(l);
		l.add(l.size(),21);
		System.out.println(l);

	}

}
