package com.linkedlst_Assignment;

import java.util.LinkedList;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> l=new LinkedList<>();
		l.add(10);
		l.add(11);
		l.add(12);
		l.add(13);
		l.add(14);
		System.out.println(l);
		//Append element at last
		l.addLast(15);
		System.out.println(l);


	}

}
