package com.loop_assignements;
//4.Write a Java program to print all alphabets from a to z. - using  for loop
public class print_a_to_z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='a';ch<='z';ch++)
		{
			System.out.println(ch);
		}

	}

}
