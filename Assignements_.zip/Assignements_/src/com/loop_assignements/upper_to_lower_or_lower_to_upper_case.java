package com.loop_assignements;
import java.util.*;
public class upper_to_lower_or_lower_to_upper_case {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Character");
		char ch1=sc.next().charAt(0);
		for(char ch='a';ch<='z';ch++)
		{
//			if(ch==ch1)
			{
				System.out.println(ch);
			}
		}
		 
	}

}
