package com.loop_assignements;

public class Total_of_items {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k = 0;
		for (int i = 1; i <= 100; i++) {
			k = k + i;
		}
		System.out.println(k + " is total price of 100 items");
	}

}
