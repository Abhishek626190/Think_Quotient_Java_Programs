package com.loop_assignements;
//3.WAP to print even numbers from 121 to 229 using do-while loop. 
public class Display_121to229_do_while {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=121;
		do{
			if(i%2==0)
			{
			System.out.println(i);
 			}
			i++;
		}while(i<=229);
	}

}
