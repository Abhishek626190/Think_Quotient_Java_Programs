package com.loop_assignements;
import java.util.*;

public class Table_of_given_number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		 
		for(int i=1;i<=10;i++)
		{
	      
           System.out.println(num*i );

		}
		 

	}

}
