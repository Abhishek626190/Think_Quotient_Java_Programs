package com.loop_assignements;
//1.WAP to print even numbers from 121 to 229 using for loop
public class Display_121to229 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=121;i<=229;i++)
		{
		   if(i%2==0)
		   {
			   System.out.println(i);
		   }
		}

	}

}
