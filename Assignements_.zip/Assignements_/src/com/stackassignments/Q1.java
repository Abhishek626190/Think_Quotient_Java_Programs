package com.stackassignments;

import java.util.Stack;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Stack st=new Stack();
//		st.push((Integer)1);
//		st.push((Integer)8);
//		st.push((Integer)11);
//		st.push((Integer)116);
//		st.push((Integer)105);
//		st.push(181);
//
//		System.out.println(st);

		
	}

}
