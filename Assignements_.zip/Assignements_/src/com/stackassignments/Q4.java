package com.stackassignments;

import java.util.Stack;

public class Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer>st=new Stack<>();
		st.push(1);
		st.push(8);
		st.push(11);
		st.push(116);
		st.push(105);
		st.push(181);
		st.addElement(374);
		st.add(786);
		st.add(1,144);
		st.add(5,370);
		System.out.println(st);

	}

}
