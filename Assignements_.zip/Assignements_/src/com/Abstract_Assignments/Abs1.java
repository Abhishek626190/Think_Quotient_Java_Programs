package com.Abstract_Assignments;

public abstract class Abs1 {
	public void doAbs1()
	{
		System.out.println("doabs method in Abs1 class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
abstract class Abs2
{
	public void doAbs2()
	{
		System.out.println("doAbs2 method in Abs2 class");
	}
}
//class Temp extends Abs1,Abs2
//{
//	// We can not extends more than one class at a time
//}

