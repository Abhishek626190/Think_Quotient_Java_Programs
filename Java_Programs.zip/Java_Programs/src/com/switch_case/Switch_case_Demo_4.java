package com.switch_case;

public class Switch_case_Demo_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int price = 6;
		switch (price)
		{
			case 2: System.out.println("It is: 2");
			default: System.out.println("It is: default");
			case 5: System.out.println("It is: 5");
			case 9: System.out.println("It is: 9");
		}


	}

}
