package com.switch_case;

public class Display_1to5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=0;
		switch(num)
		{
		case 0:System.out.println("1\n2\n3\n4\n5");break;
		}

	}

}
