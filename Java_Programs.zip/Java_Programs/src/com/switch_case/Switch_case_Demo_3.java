package com.switch_case;

public class Switch_case_Demo_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int code = 3;
        
        switch(code)
        {
            case 1:
                System.out.println("Wish");
            case 2:
                System.out.println("You");
            default:
                System.out.println("A");
            case 3:
                System.out.println("Happy");
            case 4:
                System.out.println("New");
            case 5:
                System.out.println("Year");
        }


	}

}
