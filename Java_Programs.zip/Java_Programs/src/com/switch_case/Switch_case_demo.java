package com.switch_case;

public class Switch_case_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int k = 65;
        switch (k) {
            default :
                System.out.print("Website ");
            case 65 :
                System.out.print("Merit ");
            case 'k' :
                System.out.print("Campus ");
            case 'j' :
                System.out.print("Java ");
                break;
        }


	}

}
