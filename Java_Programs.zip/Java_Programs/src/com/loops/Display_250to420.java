package com.loops;

public class Display_250to420 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=250;i<=420;i++)
		{
			System.out.println(i);
		}

	}

}
