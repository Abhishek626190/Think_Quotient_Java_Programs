package com.loops;
import java.util.*;

public class Demo_loop {
	public static void main(String[]args) {
//	Scanner sc=new Scanner(System.in);
//	int i=sc.nextInt();
//	    for(int i=1;i<=5;i++)
//	    {
//		System.out.println("Hi");
//	    }
//		for(int i=1;i<=5;i++)
//		{
//			System.out.println(i);
//		}
//		for(int i=4;i>=1;i--)
//		{
//			System.out.println(i);
//		}
//		for(int i=1;i<=5;i--)
//		{
//			System.out.println(i);
//		}
//		int i=1;
//		for(;i<=5;i++)
//			{
//				System.out.println("Hi");
//			}
//		for(int i=1;i<=5;i--)
//		{
//			System.out.println("Hi");
//		}
//		for(int i=1;i<=5;)
//		{
//			System.out.println(i);
//		} 
//		for(int i=1;i<=5;i++);
//		{
//			System.out.println("Hi");
//		}
//		for(;;)
//		{
//			System.out.println("Hi");
//		}
	
		

}
}
