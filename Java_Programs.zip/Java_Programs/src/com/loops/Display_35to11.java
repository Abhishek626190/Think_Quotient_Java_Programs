package com.loops;

public class Display_35to11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=35;i>=11;i--)
		{
			System.out.println(i);
		}
	}

}
