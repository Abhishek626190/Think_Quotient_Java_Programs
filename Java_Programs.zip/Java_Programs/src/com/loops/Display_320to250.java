package com.loops;

public class Display_320to250 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=320;i>=250;i--)
		{
			System.out.println(i);
		}

	}

}
