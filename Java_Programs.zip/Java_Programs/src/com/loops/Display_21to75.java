package com.loops;

public class Display_21to75 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=21;i<=75;i++)
		{
			System.out.println(i);
		}

	}

}
