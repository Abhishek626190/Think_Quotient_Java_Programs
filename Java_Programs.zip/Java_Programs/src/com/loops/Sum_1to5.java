package com.loops;

public class Sum_1to5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=1;i<=5;i++)
		{
			sum=sum+i;
		}
		System.out.println(sum);

	}

}
