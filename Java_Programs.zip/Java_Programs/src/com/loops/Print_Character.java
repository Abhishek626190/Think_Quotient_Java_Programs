package com.loops;

public class Print_Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='z';ch>='a';ch--)
		{
			System.out.print(ch+",");
		}

	}

}
