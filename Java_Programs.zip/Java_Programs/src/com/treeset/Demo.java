package com.treeset;

import java.util.TreeSet;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String>ts=new TreeSet<>();
		ts.add("Abhi");
		ts.add("Aadarsh");
		ts.add("Vivek");
		ts.add("Suraj");
		System.out.println(ts);
	}

}
