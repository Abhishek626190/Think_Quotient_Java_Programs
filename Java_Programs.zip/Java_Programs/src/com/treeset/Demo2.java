package com.treeset;

import java.util.TreeSet;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String>ts=new TreeSet<>();
		ts.add("Sunny");
		ts.add("Bunny");
		ts.add(null);
		ts.add("Honey");
		ts.add("Ghanii");
		System.out.println(ts);

	}

}
