package com.Inheritance_Demo;
class Card
{
//	Card()
//	{
//		
//	}
	Card(int price)
	{
		 
	}
}
class WeddingCard extends Card
{
	WeddingCard()
	{
		super(10);
	}
}
public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
