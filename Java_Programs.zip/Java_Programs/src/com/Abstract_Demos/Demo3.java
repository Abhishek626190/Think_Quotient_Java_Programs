package com.Abstract_Demos;

public abstract class Demo3 {
	abstract void m1();
	public static void m2()
	{
		System.out.println("Method of abstract class Demo3");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		m2();

	}

}
