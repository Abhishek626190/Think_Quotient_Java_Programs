package com.treemap;

import java.util.TreeMap;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String> tmap = new TreeMap<>();
		tmap.put(101, "Hassena");
		tmap.put(105, "Raveena");
		tmap.put(108, "Saveena");
		tmap.put(104, "Kareena");
		tmap.put(106, "Sarrena");

		System.out.println(tmap);
		
		

	}

}
