package com.treemap;

import java.util.TreeMap;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<String, Integer> tmap = new TreeMap<>();
		tmap.put("Shyam", 103);
		tmap.put("Ganshyam", 106);
		tmap.put("AatmaRam", 100);
		tmap.put("TukaRam", 104);
		tmap.put("VishRam", 109);
		System.out.println(tmap);

	}

}
