package com.stringBuilder;

public class Reverse_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str=new StringBuilder("Abhishek");
		str.reverse();
		System.out.println(str);
		str.reverse();
		System.out.println(str);

	}

}
