package com.stringBuilder;

public class Replace_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str=new StringBuilder("Abhishek");
		System.out.println(str.replace(4, str.length(), " Rai"));

	}

}
