package com.stringBuilder;

public class Insert_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str=new StringBuilder("Abhi");
		str.insert(1, "shek");
		System.out.println(str);
		System.out.println(str.insert(1, "bhi"));

	}

}
