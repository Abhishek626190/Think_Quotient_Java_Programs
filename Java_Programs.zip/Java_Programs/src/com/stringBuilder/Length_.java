package com.stringBuilder;

public class Length_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str=new StringBuilder("Abhishek Rai");
		int leng=str.length();
		System.out.println(leng);
		System.out.println(str.length());
		

	}

}
