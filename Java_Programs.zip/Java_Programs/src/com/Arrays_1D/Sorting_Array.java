package com.Arrays_1D;

import java.util.Arrays;

public class Sorting_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {8,7,2,6,4,2};
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));

		

	}

}
