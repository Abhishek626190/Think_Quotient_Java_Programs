package com.display_series;

public class Display_Series_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=1;int n=0;
		for(int i=1;i<=10;i++)
		{
			sum=sum+n;
			System.out.println(sum);
			n++;
		}

	}

}
