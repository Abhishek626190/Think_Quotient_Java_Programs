package com.variables;

public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5;
		int b=2;
		int power;
		power=(int)Math.pow(a,b);
		System.out.println("The result is="+power);
//		b=(-1*-1);
//		System.out.println("The result is="+b);

	}

}
