package com.variables;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
//		int n=i++%5;
		int n=++i%5;
		
		System.out.println(i);
		System.out.println(n);

	}

}
