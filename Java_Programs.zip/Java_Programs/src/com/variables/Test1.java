package com.variables;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=50001;
		short s=100;
		byte b=20;
		long l=500000l;
		float f=10.25451f;
		double d=12.2566455151;
		boolean bo=true;
		char ch='a';
		System.out.println(i);
		System.out.println(s);
		System.out.println(b);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(ch);
		System.out.println(bo);
		char ch1='2';
		System.out.println(ch1);
		System.out.println(i+"\n"+s+","+bo);









	}

}
