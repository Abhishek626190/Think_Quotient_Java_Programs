package com.variables;

public class Area {
public static void main(String[]args)
{
	 
	float r=5;
	float pi=3.14f;
	int l=5;
	int b=10;
	int a=5;
	
	System.out.println("The area of circle is "+(pi*r*r));
	System.out.println("The area of rectangle is "+(l*b));
	System.out.println("The perimeter of rectangle is "+(2*(l*b)));
	System.out.println("The area of square is "+(a*a));
}
}
;