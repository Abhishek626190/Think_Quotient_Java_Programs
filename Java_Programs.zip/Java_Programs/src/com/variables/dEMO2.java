package com.variables;

public class dEMO2
{                
	public static void main(String[]args)
	{
	double d;
	d=((25.5*3.5-3.5*3.5)/(40.5-4.5));
	System.out.println("The output is =" +d);
	}
}
     