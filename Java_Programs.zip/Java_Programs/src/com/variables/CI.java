package com.variables;

public class CI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double p=1000;
		double r=5;
		double t=2;
		double si;
		si=p*r*t/100;
		System.out.println("The Simple Interest is="+si);

	}

}
