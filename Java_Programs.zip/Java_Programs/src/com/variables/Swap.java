package com.variables;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=5;
//		int c=0;
//		Swap values of two variables with using third variable:
//		c=b; 
//		b=a;
//		a=c;
//		Swap values of two variables without using third variable:
//		b=a;
//		a=a+b;
//		a=a-b;
		System.out.println("The value after swapping is :"+a+" " +b);
		
		

	}

}
