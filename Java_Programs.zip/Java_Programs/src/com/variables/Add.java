package com.variables;

public class Add {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=7;
		int num2=5;
		int add;
		System.out.println("Addition="+num1+num2);
		System.out.println("Addition="+(num1+num2));
		System.out.println("Addition="+num1+"\t"+num2);
		System.out.println("Addition=\n"+num1+"\n"+num2);
		System.out.println("Addition=\r"+num1+"\r"+num2);
        System.out.println(add=num1+num2);
        System.out.println(add);
        
	}
	

}
