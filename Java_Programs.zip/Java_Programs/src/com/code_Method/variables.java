package com.code_Method;

public class variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int num_1=5;
//		int 1_num=2;//error
//		int $1=1;
//		int _=3;//single underscore are not allowed after 1.8v onwards
//		int __=3;
//		int sum$=4;
//		int t_$=6;
//		int _$=7;
//		System.out.println(num_1+$1+__+sum$+t_$+_$);
		// Type Cnversion:
		double d = 12.5;
		// int n=d;//error
		int n = (int) d;
		// float pi=3.14;//error
		float pi = 3.14f;
		System.out.println(n + "," + pi);
	}

}
