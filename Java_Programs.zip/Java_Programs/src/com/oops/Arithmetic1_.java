package com.oops;

public class Arithmetic1_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arithmetic_ obj = new Arithmetic_();
		obj.mul(10, 20);
		obj.mul(10.0, 20.0);
		obj.mul(10f, 20f);
		obj.mul((short)10, (short)20);

	}

}
