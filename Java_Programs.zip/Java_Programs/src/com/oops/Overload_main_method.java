package com.oops;

public class Overload_main_method {
//	public static void main(int args)
//	{
//		System.out.println("Hello int");
//	}

	public static void main(String[] args) {
	System.out.println("hello string");
	Overload_main_method obj=new Overload_main_method();
	main(12);
	
		
	}
	public static void main(int args)
	{
		System.out.println("Hello int");
	}
 		
		

}	



