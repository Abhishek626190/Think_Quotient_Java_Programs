package com.String;

public class Contain_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Abhishek";
		System.out.println(str.contains("Abhi"));
		System.out.println(str.contains("shek"));
		System.out.println(str.contains("ABHI"));
		System.out.println(str.contains("SHEK"));




	}

}
