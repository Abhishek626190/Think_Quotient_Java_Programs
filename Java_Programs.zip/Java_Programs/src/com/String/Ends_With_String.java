package com.String;

public class Ends_With_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Abhishek";
		System.out.println(str.endsWith("shek"));
		System.out.println(str.endsWith("Abhi"));

		

	}

}
