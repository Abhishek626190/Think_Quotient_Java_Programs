package com.String;

public class CharacterAt_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Abhishek";
		for(int i=0;i<s1.length();i++)
		{
			System.out.println(i+"="+s1.charAt(i));
		}

	}

}
