package com.String;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		String s=("Abhishek");
		System.out.println(s);
		System.out.println(s.length());
		for(int i=0;i<s.length();i++)
		{
			System.out.print(s.charAt(i)+" ");
		}
		 

	}

}
