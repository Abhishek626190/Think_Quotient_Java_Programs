package com.String;

public class Replace_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="abhishek";
		String str1=str.replace("shek"," Rai");
		System.out.println(str1);
		System.out.println(str);
		System.out.println(str.replaceFirst("abh", "ABH"));

	}

}
