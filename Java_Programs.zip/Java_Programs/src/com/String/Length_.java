package com.String;

public class Length_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str=new StringBuffer("Abhishek");
		int len=str.length();
		System.out.println(len);
		System.out.println(str.length());

	}

}
