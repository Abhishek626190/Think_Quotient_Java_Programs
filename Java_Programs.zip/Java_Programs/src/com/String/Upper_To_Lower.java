package com.String;

public class Upper_To_Lower {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="abhishek";
		String s=str.toUpperCase();
		System.out.println(s);
		

	}

}
