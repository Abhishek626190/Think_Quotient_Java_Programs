package com.String;

public class Length_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Abhishek Rai";
		System.out.println(s.length());

	}

}
