package com.String;

public class Starts_With_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Abhishek";
		System.out.println(str.startsWith("Abhi"));
		System.out.println(str.startsWith("shek"));


	}

}
