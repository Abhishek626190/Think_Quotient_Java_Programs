package com.String;

public class FInd_Length_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Abhi";
		//Convert string to characters
		char ch[]=s.toCharArray();
		System.out.println(ch.length);
		 
	}

}
