package com.String;

public class IndextAt_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Abhishek";
		
		System.out.println(s.indexOf('i'));
		System.out.println(s.charAt(0));
		System.out.println(s.lastIndexOf(s));
		 
	}

}
