package com.String_Buffer;

public class Append_SB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str=new StringBuffer("Abhishek");
		StringBuffer str1=new StringBuffer(" Rai");
		StringBuffer s=str.append(str1);
		System.out.println(s);
		System.out.println(str);
		
	}

}
