package com.String_Buffer;

public class Reverse_SB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str=new StringBuffer("Hello");
		str.reverse();
		System.out.println(str);
		StringBuffer str1=new StringBuffer("MadaM");
		str1.reverse();
		System.out.println(str1);
		

	}

}
