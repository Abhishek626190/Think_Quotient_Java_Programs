package com.accessmodifier;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
class Student1 
{
	int rollNum;
	int courseId;
	int age;
	int admissionNum;
	
}
