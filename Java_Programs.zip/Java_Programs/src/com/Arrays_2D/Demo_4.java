package com.Arrays_2D;

public class Demo_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
